<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_72b1549de4f2c6cbd7fd53529b802ec32618c2806981bf4363d16c9fa45d34a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_128ce2f8b3ceded5e09cecb682d276ab8033cb14ee0739fd6128f38249a67cba = $this->env->getExtension("native_profiler");
        $__internal_128ce2f8b3ceded5e09cecb682d276ab8033cb14ee0739fd6128f38249a67cba->enter($__internal_128ce2f8b3ceded5e09cecb682d276ab8033cb14ee0739fd6128f38249a67cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_128ce2f8b3ceded5e09cecb682d276ab8033cb14ee0739fd6128f38249a67cba->leave($__internal_128ce2f8b3ceded5e09cecb682d276ab8033cb14ee0739fd6128f38249a67cba_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
