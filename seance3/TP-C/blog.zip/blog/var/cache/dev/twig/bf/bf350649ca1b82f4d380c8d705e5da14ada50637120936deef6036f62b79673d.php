<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_8bd8dd9d73e471235788c08adb5f61c7d506aa77b0bc855bfa9acb7aaf0d7281 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e6c105e1905bf6bedf9445a72e7230de7f66b5c00a172b237cb62e82f61e80a = $this->env->getExtension("native_profiler");
        $__internal_5e6c105e1905bf6bedf9445a72e7230de7f66b5c00a172b237cb62e82f61e80a->enter($__internal_5e6c105e1905bf6bedf9445a72e7230de7f66b5c00a172b237cb62e82f61e80a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_5e6c105e1905bf6bedf9445a72e7230de7f66b5c00a172b237cb62e82f61e80a->leave($__internal_5e6c105e1905bf6bedf9445a72e7230de7f66b5c00a172b237cb62e82f61e80a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
