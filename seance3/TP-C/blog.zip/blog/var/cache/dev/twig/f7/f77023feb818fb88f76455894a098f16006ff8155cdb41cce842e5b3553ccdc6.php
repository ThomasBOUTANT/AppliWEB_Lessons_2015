<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_017c0f7a96de53fec8c1d2d5ed1e9a389ca5f4fab0a174e6f7c8fe8e1f41aad5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3baeeb11ef7fafe20ba27159998dd56b24c6e0a138770a2f71f8aa0748a1ae28 = $this->env->getExtension("native_profiler");
        $__internal_3baeeb11ef7fafe20ba27159998dd56b24c6e0a138770a2f71f8aa0748a1ae28->enter($__internal_3baeeb11ef7fafe20ba27159998dd56b24c6e0a138770a2f71f8aa0748a1ae28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_3baeeb11ef7fafe20ba27159998dd56b24c6e0a138770a2f71f8aa0748a1ae28->leave($__internal_3baeeb11ef7fafe20ba27159998dd56b24c6e0a138770a2f71f8aa0748a1ae28_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
