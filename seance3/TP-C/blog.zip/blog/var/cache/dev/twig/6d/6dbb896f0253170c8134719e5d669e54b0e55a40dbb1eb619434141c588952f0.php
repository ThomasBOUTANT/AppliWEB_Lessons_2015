<?php

/* FOSUserBundle:ChangePassword:change_password.html.twig */
class __TwigTemplate_4f4e4fc9b1cc516dcc174be95dcdb5d3e511542068f129d42994a5e543f34cf6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8acc21a7a5a5ce7c0116adaf7a76ea5b03ad8fa919a25665c78273923629e57 = $this->env->getExtension("native_profiler");
        $__internal_a8acc21a7a5a5ce7c0116adaf7a76ea5b03ad8fa919a25665c78273923629e57->enter($__internal_a8acc21a7a5a5ce7c0116adaf7a76ea5b03ad8fa919a25665c78273923629e57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a8acc21a7a5a5ce7c0116adaf7a76ea5b03ad8fa919a25665c78273923629e57->leave($__internal_a8acc21a7a5a5ce7c0116adaf7a76ea5b03ad8fa919a25665c78273923629e57_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_e2280ad65371554daada160378754efcf41279e3818c525490a26157b1f5135e = $this->env->getExtension("native_profiler");
        $__internal_e2280ad65371554daada160378754efcf41279e3818c525490a26157b1f5135e->enter($__internal_e2280ad65371554daada160378754efcf41279e3818c525490a26157b1f5135e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:change_password_content.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 4)->display($context);
        
        $__internal_e2280ad65371554daada160378754efcf41279e3818c525490a26157b1f5135e->leave($__internal_e2280ad65371554daada160378754efcf41279e3818c525490a26157b1f5135e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:change_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:change_password_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
