<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_e00e0a08badf5e8a205c0adc4c86aae1223896febb2c758a9894d5e707e867af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c607dc81229402e7a455aa65e907eeb2371644f6ab80e47b5eccf4ced55bb0c7 = $this->env->getExtension("native_profiler");
        $__internal_c607dc81229402e7a455aa65e907eeb2371644f6ab80e47b5eccf4ced55bb0c7->enter($__internal_c607dc81229402e7a455aa65e907eeb2371644f6ab80e47b5eccf4ced55bb0c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_c607dc81229402e7a455aa65e907eeb2371644f6ab80e47b5eccf4ced55bb0c7->leave($__internal_c607dc81229402e7a455aa65e907eeb2371644f6ab80e47b5eccf4ced55bb0c7_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
