<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_832a9140403a82fe58ca70506e62f50fdcf5d2f4cb23a357c0c6e2657fef9f7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e0bf0bdc31cc2ab913e8dde3100cf48e8403cc1d78fb6edc4f93fb8672b8e36f = $this->env->getExtension("native_profiler");
        $__internal_e0bf0bdc31cc2ab913e8dde3100cf48e8403cc1d78fb6edc4f93fb8672b8e36f->enter($__internal_e0bf0bdc31cc2ab913e8dde3100cf48e8403cc1d78fb6edc4f93fb8672b8e36f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_e0bf0bdc31cc2ab913e8dde3100cf48e8403cc1d78fb6edc4f93fb8672b8e36f->leave($__internal_e0bf0bdc31cc2ab913e8dde3100cf48e8403cc1d78fb6edc4f93fb8672b8e36f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
