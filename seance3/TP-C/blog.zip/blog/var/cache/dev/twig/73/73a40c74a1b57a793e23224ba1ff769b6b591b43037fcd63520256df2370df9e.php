<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_d8d0ebe3f941728291c6851a4d088fda2a765ee226b4d4f656f718b26dc21a01 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0e6e3fbd39a4b417c7dccdde2a212f3f097bf72f150d0298b2afcf6b5db6432 = $this->env->getExtension("native_profiler");
        $__internal_d0e6e3fbd39a4b417c7dccdde2a212f3f097bf72f150d0298b2afcf6b5db6432->enter($__internal_d0e6e3fbd39a4b417c7dccdde2a212f3f097bf72f150d0298b2afcf6b5db6432_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_d0e6e3fbd39a4b417c7dccdde2a212f3f097bf72f150d0298b2afcf6b5db6432->leave($__internal_d0e6e3fbd39a4b417c7dccdde2a212f3f097bf72f150d0298b2afcf6b5db6432_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */
