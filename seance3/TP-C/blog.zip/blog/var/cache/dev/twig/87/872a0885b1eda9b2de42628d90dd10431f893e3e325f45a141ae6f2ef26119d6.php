<?php

/* WebProfilerBundle:Collector:exception.html.twig */
class __TwigTemplate_e1e0eb018e6c8043917dc450d617309bb1ff8e5a07834b7e1cd415ed2af64268 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ebe7b8e3f307bac4ff0e15400083c0a1827c576aaaf532d895fd8a23b8f69b0 = $this->env->getExtension("native_profiler");
        $__internal_0ebe7b8e3f307bac4ff0e15400083c0a1827c576aaaf532d895fd8a23b8f69b0->enter($__internal_0ebe7b8e3f307bac4ff0e15400083c0a1827c576aaaf532d895fd8a23b8f69b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0ebe7b8e3f307bac4ff0e15400083c0a1827c576aaaf532d895fd8a23b8f69b0->leave($__internal_0ebe7b8e3f307bac4ff0e15400083c0a1827c576aaaf532d895fd8a23b8f69b0_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a90c2b6540ee594f5576ec91ce3b776e9fc99186bf93d7c1e4ca46f9efdbe6e6 = $this->env->getExtension("native_profiler");
        $__internal_a90c2b6540ee594f5576ec91ce3b776e9fc99186bf93d7c1e4ca46f9efdbe6e6->enter($__internal_a90c2b6540ee594f5576ec91ce3b776e9fc99186bf93d7c1e4ca46f9efdbe6e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_a90c2b6540ee594f5576ec91ce3b776e9fc99186bf93d7c1e4ca46f9efdbe6e6->leave($__internal_a90c2b6540ee594f5576ec91ce3b776e9fc99186bf93d7c1e4ca46f9efdbe6e6_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5087dc43adf721f0a893e707e03f3e4cb6c519e5022bc9727c088c96a2d96863 = $this->env->getExtension("native_profiler");
        $__internal_5087dc43adf721f0a893e707e03f3e4cb6c519e5022bc9727c088c96a2d96863->enter($__internal_5087dc43adf721f0a893e707e03f3e4cb6c519e5022bc9727c088c96a2d96863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_5087dc43adf721f0a893e707e03f3e4cb6c519e5022bc9727c088c96a2d96863->leave($__internal_5087dc43adf721f0a893e707e03f3e4cb6c519e5022bc9727c088c96a2d96863_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e00cfb68cfbcf3236feec29720f088e80d277d159aadd41c510f578047b89836 = $this->env->getExtension("native_profiler");
        $__internal_e00cfb68cfbcf3236feec29720f088e80d277d159aadd41c510f578047b89836->enter($__internal_e00cfb68cfbcf3236feec29720f088e80d277d159aadd41c510f578047b89836_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_e00cfb68cfbcf3236feec29720f088e80d277d159aadd41c510f578047b89836->leave($__internal_e00cfb68cfbcf3236feec29720f088e80d277d159aadd41c510f578047b89836_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 33,  114 => 32,  108 => 28,  106 => 27,  102 => 25,  96 => 24,  88 => 21,  82 => 17,  80 => 16,  75 => 14,  70 => 13,  64 => 12,  54 => 9,  48 => 6,  45 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     {% if collector.hasexception %}*/
/*         <style>*/
/*             {{ render(path('_profiler_exception_css', { token: token })) }}*/
/*         </style>*/
/*     {% endif %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block menu %}*/
/*     <span class="label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}">*/
/*         <span class="icon">{{ include('@WebProfiler/Icon/exception.svg') }}</span>*/
/*         <strong>Exception</strong>*/
/*         {% if collector.hasexception %}*/
/*             <span class="count">*/
/*                 <span>1</span>*/
/*             </span>*/
/*         {% endif %}*/
/*     </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     <h2>Exceptions</h2>*/
/* */
/*     {% if not collector.hasexception %}*/
/*         <div class="empty">*/
/*             <p>No exception was thrown and caught during the request.</p>*/
/*         </div>*/
/*     {% else %}*/
/*         <div class="sf-reset">*/
/*             {{ render(path('_profiler_exception', { token: token })) }}*/
/*         </div>*/
/*     {% endif %}*/
/* {% endblock %}*/
/* */
