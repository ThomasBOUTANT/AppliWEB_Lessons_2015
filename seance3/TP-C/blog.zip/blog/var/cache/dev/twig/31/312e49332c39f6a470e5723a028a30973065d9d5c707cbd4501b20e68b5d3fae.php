<?php

/* blog/blogbase.html.twig */
class __TwigTemplate_a493dd8e701a4995e125da9efe6154f2277c93dbf6cafe6b8a15de80496eba6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/blogbase.html.twig", 1);
        $this->blocks = array(
            'header' => array($this, 'block_header'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3280d4d56ea47d59e67541a530ae1f804197beb932e615a2f0c9dcfdcccdd663 = $this->env->getExtension("native_profiler");
        $__internal_3280d4d56ea47d59e67541a530ae1f804197beb932e615a2f0c9dcfdcccdd663->enter($__internal_3280d4d56ea47d59e67541a530ae1f804197beb932e615a2f0c9dcfdcccdd663_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/blogbase.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3280d4d56ea47d59e67541a530ae1f804197beb932e615a2f0c9dcfdcccdd663->leave($__internal_3280d4d56ea47d59e67541a530ae1f804197beb932e615a2f0c9dcfdcccdd663_prof);

    }

    // line 3
    public function block_header($context, array $blocks = array())
    {
        $__internal_bb347a76c20dc86e4687d70d5b9b83540d149076ffab6368aca5a4014f50a3d2 = $this->env->getExtension("native_profiler");
        $__internal_bb347a76c20dc86e4687d70d5b9b83540d149076ffab6368aca5a4014f50a3d2->enter($__internal_bb347a76c20dc86e4687d70d5b9b83540d149076ffab6368aca5a4014f50a3d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        echo "<header><p><a href=\"";
        echo $this->env->getExtension('routing')->getPath("app_blog_list");
        echo "\">Accueil</a></p></header>";
        
        $__internal_bb347a76c20dc86e4687d70d5b9b83540d149076ffab6368aca5a4014f50a3d2->leave($__internal_bb347a76c20dc86e4687d70d5b9b83540d149076ffab6368aca5a4014f50a3d2_prof);

    }

    public function getTemplateName()
    {
        return "blog/blogbase.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block header %}<header><p><a href="{{ path('app_blog_list') }}">Accueil</a></p></header>{% endblock %}*/
/* */
