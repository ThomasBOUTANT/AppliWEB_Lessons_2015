<?php

/* :blog:list.html.twig */
class __TwigTemplate_474b89fc78e39575a00ff23a237a98cadd28541ae66cb207211fb21ef3899514 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("blog/blogbase.html.twig", ":blog:list.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "blog/blogbase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_efc7cd5fba05a71cc1f4305a5e52ac9c94a9bc05df6826740fde3e4fed583f49 = $this->env->getExtension("native_profiler");
        $__internal_efc7cd5fba05a71cc1f4305a5e52ac9c94a9bc05df6826740fde3e4fed583f49->enter($__internal_efc7cd5fba05a71cc1f4305a5e52ac9c94a9bc05df6826740fde3e4fed583f49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_efc7cd5fba05a71cc1f4305a5e52ac9c94a9bc05df6826740fde3e4fed583f49->leave($__internal_efc7cd5fba05a71cc1f4305a5e52ac9c94a9bc05df6826740fde3e4fed583f49_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f45582dda40d51af67a07d907b61c3e92b921b9c40ead825efad80ef5d7b7f1d = $this->env->getExtension("native_profiler");
        $__internal_f45582dda40d51af67a07d907b61c3e92b921b9c40ead825efad80ef5d7b7f1d->enter($__internal_f45582dda40d51af67a07d907b61c3e92b921b9c40ead825efad80ef5d7b7f1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "List of Posts";
        
        $__internal_f45582dda40d51af67a07d907b61c3e92b921b9c40ead825efad80ef5d7b7f1d->leave($__internal_f45582dda40d51af67a07d907b61c3e92b921b9c40ead825efad80ef5d7b7f1d_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_9e6b4015a4917ad1ea7099a187807c74dd4bdc2e31a733d17277b3b75843fc66 = $this->env->getExtension("native_profiler");
        $__internal_9e6b4015a4917ad1ea7099a187807c74dd4bdc2e31a733d17277b3b75843fc66->enter($__internal_9e6b4015a4917ad1ea7099a187807c74dd4bdc2e31a733d17277b3b75843fc66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>List of Posts</h1>
    <ul>
        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 9
            echo "        <li>
            <a href=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("app_blog_show", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\">
                ";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
            </a>
        </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "    </ul>
";
        
        $__internal_9e6b4015a4917ad1ea7099a187807c74dd4bdc2e31a733d17277b3b75843fc66->leave($__internal_9e6b4015a4917ad1ea7099a187807c74dd4bdc2e31a733d17277b3b75843fc66_prof);

    }

    public function getTemplateName()
    {
        return ":blog:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 15,  68 => 11,  64 => 10,  61 => 9,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'blog/blogbase.html.twig' %}*/
/* */
/* {% block title %}List of Posts{% endblock %}*/
/* */
/* {% block main %}*/
/*     <h1>List of Posts</h1>*/
/*     <ul>*/
/*         {% for post in posts %}*/
/*         <li>*/
/*             <a href="{{ path('app_blog_show', {'id': post.id}) }}">*/
/*                 {{ post.title }}*/
/*             </a>*/
/*         </li>*/
/*         {% endfor %}*/
/*     </ul>*/
/* {% endblock %}*/
/* */
