<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_dc3e19484b775d3744da204b58dfe49f39cb731a87df3f671c6240a2a7c59f21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_807a2d701c237217efd9801783883b94db374da5b4547436b6b9a7e9b9078d9d = $this->env->getExtension("native_profiler");
        $__internal_807a2d701c237217efd9801783883b94db374da5b4547436b6b9a7e9b9078d9d->enter($__internal_807a2d701c237217efd9801783883b94db374da5b4547436b6b9a7e9b9078d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_807a2d701c237217efd9801783883b94db374da5b4547436b6b9a7e9b9078d9d->leave($__internal_807a2d701c237217efd9801783883b94db374da5b4547436b6b9a7e9b9078d9d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
