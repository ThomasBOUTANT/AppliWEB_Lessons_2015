<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_f2a6e2ae1d421a4e4e5768821ffc1b5da3ed7ca3a814ea23c7843599c9c6ae44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_997982055e73e6a817c35915e02c30768af976f8b8ebd700ac213f31ee93f171 = $this->env->getExtension("native_profiler");
        $__internal_997982055e73e6a817c35915e02c30768af976f8b8ebd700ac213f31ee93f171->enter($__internal_997982055e73e6a817c35915e02c30768af976f8b8ebd700ac213f31ee93f171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_997982055e73e6a817c35915e02c30768af976f8b8ebd700ac213f31ee93f171->leave($__internal_997982055e73e6a817c35915e02c30768af976f8b8ebd700ac213f31ee93f171_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
