<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_d18bbe4e575638efae33c568d44dcb308004a2b426347398ae5f3318c228b618 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76a42dd0e83d46541c968eec17d121c7f11f3f1d9ca585c09f0eb3b6f20b46b2 = $this->env->getExtension("native_profiler");
        $__internal_76a42dd0e83d46541c968eec17d121c7f11f3f1d9ca585c09f0eb3b6f20b46b2->enter($__internal_76a42dd0e83d46541c968eec17d121c7f11f3f1d9ca585c09f0eb3b6f20b46b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76a42dd0e83d46541c968eec17d121c7f11f3f1d9ca585c09f0eb3b6f20b46b2->leave($__internal_76a42dd0e83d46541c968eec17d121c7f11f3f1d9ca585c09f0eb3b6f20b46b2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_7a591a8bf40c00f85bb6569a45308a42e6394f33af2925484efe18d27fd5f4e5 = $this->env->getExtension("native_profiler");
        $__internal_7a591a8bf40c00f85bb6569a45308a42e6394f33af2925484efe18d27fd5f4e5->enter($__internal_7a591a8bf40c00f85bb6569a45308a42e6394f33af2925484efe18d27fd5f4e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_7a591a8bf40c00f85bb6569a45308a42e6394f33af2925484efe18d27fd5f4e5->leave($__internal_7a591a8bf40c00f85bb6569a45308a42e6394f33af2925484efe18d27fd5f4e5_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
