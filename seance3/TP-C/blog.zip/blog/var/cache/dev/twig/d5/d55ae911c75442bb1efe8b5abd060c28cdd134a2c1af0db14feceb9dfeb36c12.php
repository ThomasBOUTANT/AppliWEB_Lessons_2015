<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_2ca6505a4f130b492207d3cbf584b141cbe0bc736be21969bb898ab6eb92904f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f53a3818b5ce5fdf203b8481ff07bb17e309a7f24792b1edd7b769d08c08bc58 = $this->env->getExtension("native_profiler");
        $__internal_f53a3818b5ce5fdf203b8481ff07bb17e309a7f24792b1edd7b769d08c08bc58->enter($__internal_f53a3818b5ce5fdf203b8481ff07bb17e309a7f24792b1edd7b769d08c08bc58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_f53a3818b5ce5fdf203b8481ff07bb17e309a7f24792b1edd7b769d08c08bc58->leave($__internal_f53a3818b5ce5fdf203b8481ff07bb17e309a7f24792b1edd7b769d08c08bc58_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 4,  22 => 1,);
    }
}
/* Oops! An Error Occurred*/
/* =======================*/
/* */
/* The server returned a "{{ status_code }} {{ status_text }}".*/
/* */
/* Something is broken. Please let us know what you were doing when this error occurred.*/
/* We will fix it as soon as possible. Sorry for any inconvenience caused.*/
/* */
