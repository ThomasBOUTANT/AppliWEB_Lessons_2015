<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_a0e554cac00834bd119879de00b06b769a9812cc589036fc42961fb4b924d6ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_91b77c60fe2f8d0a5a5e184048bc9da0f411f54a3eabbb1d73a3ffb297941792 = $this->env->getExtension("native_profiler");
        $__internal_91b77c60fe2f8d0a5a5e184048bc9da0f411f54a3eabbb1d73a3ffb297941792->enter($__internal_91b77c60fe2f8d0a5a5e184048bc9da0f411f54a3eabbb1d73a3ffb297941792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_91b77c60fe2f8d0a5a5e184048bc9da0f411f54a3eabbb1d73a3ffb297941792->leave($__internal_91b77c60fe2f8d0a5a5e184048bc9da0f411f54a3eabbb1d73a3ffb297941792_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
