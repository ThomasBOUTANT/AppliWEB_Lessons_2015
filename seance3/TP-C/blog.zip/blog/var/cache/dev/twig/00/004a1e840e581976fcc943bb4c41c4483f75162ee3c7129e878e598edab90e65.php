<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_dd2790756e9ebbcdf3dfda5f222dac060b8a62fb2604f0fcbb19ad83136c9e0a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_825cab7c610560d8109eaf30e23b81fb8002d4841fe1b30b67b450445b5ec501 = $this->env->getExtension("native_profiler");
        $__internal_825cab7c610560d8109eaf30e23b81fb8002d4841fe1b30b67b450445b5ec501->enter($__internal_825cab7c610560d8109eaf30e23b81fb8002d4841fe1b30b67b450445b5ec501_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_825cab7c610560d8109eaf30e23b81fb8002d4841fe1b30b67b450445b5ec501->leave($__internal_825cab7c610560d8109eaf30e23b81fb8002d4841fe1b30b67b450445b5ec501_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($widget == 'single_text'): ?>*/
/*     <?php echo $view['form']->block($form, 'form_widget_simple'); ?>*/
/* <?php else: ?>*/
/*     <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*         <?php echo $view['form']->widget($form['date']).' '.$view['form']->widget($form['time']) ?>*/
/*     </div>*/
/* <?php endif ?>*/
/* */
