<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_60339d1d10f2efce9113efd0f97aae7e4fa53266191743b29ce0eaac44a1f283 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bb20f7c44e4841618ba46bc2eb0394ca780ea14ca295bd9187792a3d845c318 = $this->env->getExtension("native_profiler");
        $__internal_8bb20f7c44e4841618ba46bc2eb0394ca780ea14ca295bd9187792a3d845c318->enter($__internal_8bb20f7c44e4841618ba46bc2eb0394ca780ea14ca295bd9187792a3d845c318_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_8bb20f7c44e4841618ba46bc2eb0394ca780ea14ca295bd9187792a3d845c318->leave($__internal_8bb20f7c44e4841618ba46bc2eb0394ca780ea14ca295bd9187792a3d845c318_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
