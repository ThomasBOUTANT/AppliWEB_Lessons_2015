<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_bbe74f85e052289aff267bca8bb77234e630b8ff7de369660f8e74dbd1f08b11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e7073214a0dfa3526835d220b7d23097b50e32b1337a905bd3c5b8cd16612b1 = $this->env->getExtension("native_profiler");
        $__internal_5e7073214a0dfa3526835d220b7d23097b50e32b1337a905bd3c5b8cd16612b1->enter($__internal_5e7073214a0dfa3526835d220b7d23097b50e32b1337a905bd3c5b8cd16612b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_5e7073214a0dfa3526835d220b7d23097b50e32b1337a905bd3c5b8cd16612b1->leave($__internal_5e7073214a0dfa3526835d220b7d23097b50e32b1337a905bd3c5b8cd16612b1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
