<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_0961f2b44b39499735d230e94db8fb9bdf8f28c1124d6dd7fd919dd0fb653e41 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93be83407111daecd128527bd289ced32cd84021c13f3eb54a43754547008092 = $this->env->getExtension("native_profiler");
        $__internal_93be83407111daecd128527bd289ced32cd84021c13f3eb54a43754547008092->enter($__internal_93be83407111daecd128527bd289ced32cd84021c13f3eb54a43754547008092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_93be83407111daecd128527bd289ced32cd84021c13f3eb54a43754547008092->leave($__internal_93be83407111daecd128527bd289ced32cd84021c13f3eb54a43754547008092_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
