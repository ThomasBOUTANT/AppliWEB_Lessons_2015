<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_b841bc9ea3f6a4226ceaf435c2653ea4458a6f90ad7381106311310d20a6191b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76c8e399482f68a5ca12817a4690e885d651c25ec9c30548ef282ab437645afe = $this->env->getExtension("native_profiler");
        $__internal_76c8e399482f68a5ca12817a4690e885d651c25ec9c30548ef282ab437645afe->enter($__internal_76c8e399482f68a5ca12817a4690e885d651c25ec9c30548ef282ab437645afe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76c8e399482f68a5ca12817a4690e885d651c25ec9c30548ef282ab437645afe->leave($__internal_76c8e399482f68a5ca12817a4690e885d651c25ec9c30548ef282ab437645afe_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_93bb6b3b3105d780aae1f3b59f2962044b78cd63bf604ed0a7bf0aae95803d70 = $this->env->getExtension("native_profiler");
        $__internal_93bb6b3b3105d780aae1f3b59f2962044b78cd63bf604ed0a7bf0aae95803d70->enter($__internal_93bb6b3b3105d780aae1f3b59f2962044b78cd63bf604ed0a7bf0aae95803d70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_93bb6b3b3105d780aae1f3b59f2962044b78cd63bf604ed0a7bf0aae95803d70->leave($__internal_93bb6b3b3105d780aae1f3b59f2962044b78cd63bf604ed0a7bf0aae95803d70_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
