<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_64a6036bae2830d0e1297e578c5ea1c0933dabb03a8e7cdf13c396d146644f94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1385d3c8a512231fb0d27e50060c65c5547985b3a97d918e96a71d57abe2d42e = $this->env->getExtension("native_profiler");
        $__internal_1385d3c8a512231fb0d27e50060c65c5547985b3a97d918e96a71d57abe2d42e->enter($__internal_1385d3c8a512231fb0d27e50060c65c5547985b3a97d918e96a71d57abe2d42e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_1385d3c8a512231fb0d27e50060c65c5547985b3a97d918e96a71d57abe2d42e->leave($__internal_1385d3c8a512231fb0d27e50060c65c5547985b3a97d918e96a71d57abe2d42e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
