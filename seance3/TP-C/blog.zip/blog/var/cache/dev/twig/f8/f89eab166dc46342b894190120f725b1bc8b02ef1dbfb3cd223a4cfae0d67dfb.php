<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_430118db05a60f0016f677ae6e604ce9e4237db983930fe51fef391e1efc5f6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69e64eb4d928cb1e89f32522c58a154945d215c177b83f7c76903d44387327de = $this->env->getExtension("native_profiler");
        $__internal_69e64eb4d928cb1e89f32522c58a154945d215c177b83f7c76903d44387327de->enter($__internal_69e64eb4d928cb1e89f32522c58a154945d215c177b83f7c76903d44387327de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_69e64eb4d928cb1e89f32522c58a154945d215c177b83f7c76903d44387327de->leave($__internal_69e64eb4d928cb1e89f32522c58a154945d215c177b83f7c76903d44387327de_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_858e2b20547799975ecdee931197f632510d02fd569b6943dd79cc28f903e303 = $this->env->getExtension("native_profiler");
        $__internal_858e2b20547799975ecdee931197f632510d02fd569b6943dd79cc28f903e303->enter($__internal_858e2b20547799975ecdee931197f632510d02fd569b6943dd79cc28f903e303_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_858e2b20547799975ecdee931197f632510d02fd569b6943dd79cc28f903e303->leave($__internal_858e2b20547799975ecdee931197f632510d02fd569b6943dd79cc28f903e303_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
