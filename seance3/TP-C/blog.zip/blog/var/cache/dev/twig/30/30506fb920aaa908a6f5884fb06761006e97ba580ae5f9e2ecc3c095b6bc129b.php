<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_6aff1e4fd8f9e4ed04f003b6e5c356a29feebc7a32494e04fd1e66247c47d008 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f16f7dc2ba3dc66e74a1ec5776d78ef15bfa83d2c2017b2cfe2292ab6cf9a5ac = $this->env->getExtension("native_profiler");
        $__internal_f16f7dc2ba3dc66e74a1ec5776d78ef15bfa83d2c2017b2cfe2292ab6cf9a5ac->enter($__internal_f16f7dc2ba3dc66e74a1ec5776d78ef15bfa83d2c2017b2cfe2292ab6cf9a5ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f16f7dc2ba3dc66e74a1ec5776d78ef15bfa83d2c2017b2cfe2292ab6cf9a5ac->leave($__internal_f16f7dc2ba3dc66e74a1ec5776d78ef15bfa83d2c2017b2cfe2292ab6cf9a5ac_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
