<?php

/* FOSUserBundle:Resetting:password_already_requested.html.twig */
class __TwigTemplate_0064705397ea3a43f099d3a2fe6541fdfbafd49530b6e5f567fb7999e970d044 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:password_already_requested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f904f92a2242a8bb5c5b7557e3517eaa338cc13f0b8f2f7efa44fcb97431c699 = $this->env->getExtension("native_profiler");
        $__internal_f904f92a2242a8bb5c5b7557e3517eaa338cc13f0b8f2f7efa44fcb97431c699->enter($__internal_f904f92a2242a8bb5c5b7557e3517eaa338cc13f0b8f2f7efa44fcb97431c699_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:password_already_requested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f904f92a2242a8bb5c5b7557e3517eaa338cc13f0b8f2f7efa44fcb97431c699->leave($__internal_f904f92a2242a8bb5c5b7557e3517eaa338cc13f0b8f2f7efa44fcb97431c699_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6fd95881f31470c23398d2792666b95ff02c307b6a185344536f3fdaf28c5de1 = $this->env->getExtension("native_profiler");
        $__internal_6fd95881f31470c23398d2792666b95ff02c307b6a185344536f3fdaf28c5de1->enter($__internal_6fd95881f31470c23398d2792666b95ff02c307b6a185344536f3fdaf28c5de1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_6fd95881f31470c23398d2792666b95ff02c307b6a185344536f3fdaf28c5de1->leave($__internal_6fd95881f31470c23398d2792666b95ff02c307b6a185344536f3fdaf28c5de1_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:password_already_requested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
