<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_72e21e2685351300ba6bca86f2cbd87ddab69c81ef91a2e3379d8f22cf691a4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4fd7eed76bd7c6e8181f42fd22564bc4773c2af01f147c1a827bc5cd91f55d2 = $this->env->getExtension("native_profiler");
        $__internal_a4fd7eed76bd7c6e8181f42fd22564bc4773c2af01f147c1a827bc5cd91f55d2->enter($__internal_a4fd7eed76bd7c6e8181f42fd22564bc4773c2af01f147c1a827bc5cd91f55d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_a4fd7eed76bd7c6e8181f42fd22564bc4773c2af01f147c1a827bc5cd91f55d2->leave($__internal_a4fd7eed76bd7c6e8181f42fd22564bc4773c2af01f147c1a827bc5cd91f55d2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
