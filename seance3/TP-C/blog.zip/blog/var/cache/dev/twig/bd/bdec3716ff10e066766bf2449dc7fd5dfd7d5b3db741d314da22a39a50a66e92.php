<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_4e6d20d30f319fb905e8d9990c88c3cfa0981f0f0295d31054fbb2d31cec62c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5471a19c51f46490da19ff552c01e002c02cd519e65ad688b013669133903e2f = $this->env->getExtension("native_profiler");
        $__internal_5471a19c51f46490da19ff552c01e002c02cd519e65ad688b013669133903e2f->enter($__internal_5471a19c51f46490da19ff552c01e002c02cd519e65ad688b013669133903e2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_5471a19c51f46490da19ff552c01e002c02cd519e65ad688b013669133903e2f->leave($__internal_5471a19c51f46490da19ff552c01e002c02cd519e65ad688b013669133903e2f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
