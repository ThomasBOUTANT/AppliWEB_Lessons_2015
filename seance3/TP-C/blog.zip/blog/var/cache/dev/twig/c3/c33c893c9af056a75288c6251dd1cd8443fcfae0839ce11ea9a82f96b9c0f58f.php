<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_0e14007ab03ea14af262cad8b8dffcb21f1fbbb74aaa854d9041d38cf350fda8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5237fa7a01eaed85d12c76cf21019fe5c590bbf9d92c4151a75922c70780df45 = $this->env->getExtension("native_profiler");
        $__internal_5237fa7a01eaed85d12c76cf21019fe5c590bbf9d92c4151a75922c70780df45->enter($__internal_5237fa7a01eaed85d12c76cf21019fe5c590bbf9d92c4151a75922c70780df45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_5237fa7a01eaed85d12c76cf21019fe5c590bbf9d92c4151a75922c70780df45->leave($__internal_5237fa7a01eaed85d12c76cf21019fe5c590bbf9d92c4151a75922c70780df45_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
