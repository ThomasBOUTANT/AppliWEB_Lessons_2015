<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_9d73c48ede373eedeb3e60bdfcfe4ae6d41ff3833fb77cca96df06be55ff49c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc18c60a7d22ead28460e0c4c5f25450823037f7c8884739c12343bf042406c1 = $this->env->getExtension("native_profiler");
        $__internal_cc18c60a7d22ead28460e0c4c5f25450823037f7c8884739c12343bf042406c1->enter($__internal_cc18c60a7d22ead28460e0c4c5f25450823037f7c8884739c12343bf042406c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_cc18c60a7d22ead28460e0c4c5f25450823037f7c8884739c12343bf042406c1->leave($__internal_cc18c60a7d22ead28460e0c4c5f25450823037f7c8884739c12343bf042406c1_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_7199ba91c9673b7a2666c039d12c0203a8b6c224d734b315ee046a25f16d1138 = $this->env->getExtension("native_profiler");
        $__internal_7199ba91c9673b7a2666c039d12c0203a8b6c224d734b315ee046a25f16d1138->enter($__internal_7199ba91c9673b7a2666c039d12c0203a8b6c224d734b315ee046a25f16d1138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_7199ba91c9673b7a2666c039d12c0203a8b6c224d734b315ee046a25f16d1138->leave($__internal_7199ba91c9673b7a2666c039d12c0203a8b6c224d734b315ee046a25f16d1138_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
