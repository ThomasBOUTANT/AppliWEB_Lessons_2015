<?php

/* ::base.html.twig */
class __TwigTemplate_39db91c8596265f82af8d31495515dbee9eb35732450dc5801ae9270efead602 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_951ef49135548834c8dd99e8bb5001f3356ba2d82a86ec2b86dd80b21ff92115 = $this->env->getExtension("native_profiler");
        $__internal_951ef49135548834c8dd99e8bb5001f3356ba2d82a86ec2b86dd80b21ff92115->enter($__internal_951ef49135548834c8dd99e8bb5001f3356ba2d82a86ec2b86dd80b21ff92115_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
    \t";
        // line 10
        $this->displayBlock('header', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('body', $context, $blocks);
        // line 18
        echo "        ";
        $this->displayBlock('footer', $context, $blocks);
        // line 19
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 20
        echo "    </body>
</html>
";
        
        $__internal_951ef49135548834c8dd99e8bb5001f3356ba2d82a86ec2b86dd80b21ff92115->leave($__internal_951ef49135548834c8dd99e8bb5001f3356ba2d82a86ec2b86dd80b21ff92115_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b45a1d7a98081c4f5fb7d618dffabc575e14ed8dfb5498c2fe4d4a1bb2692b4b = $this->env->getExtension("native_profiler");
        $__internal_b45a1d7a98081c4f5fb7d618dffabc575e14ed8dfb5498c2fe4d4a1bb2692b4b->enter($__internal_b45a1d7a98081c4f5fb7d618dffabc575e14ed8dfb5498c2fe4d4a1bb2692b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_b45a1d7a98081c4f5fb7d618dffabc575e14ed8dfb5498c2fe4d4a1bb2692b4b->leave($__internal_b45a1d7a98081c4f5fb7d618dffabc575e14ed8dfb5498c2fe4d4a1bb2692b4b_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5f5fc95e44fd4b8b51237b7debb44cb858ed9f86ac07491c2043042b199e9fc5 = $this->env->getExtension("native_profiler");
        $__internal_5f5fc95e44fd4b8b51237b7debb44cb858ed9f86ac07491c2043042b199e9fc5->enter($__internal_5f5fc95e44fd4b8b51237b7debb44cb858ed9f86ac07491c2043042b199e9fc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_5f5fc95e44fd4b8b51237b7debb44cb858ed9f86ac07491c2043042b199e9fc5->leave($__internal_5f5fc95e44fd4b8b51237b7debb44cb858ed9f86ac07491c2043042b199e9fc5_prof);

    }

    // line 10
    public function block_header($context, array $blocks = array())
    {
        $__internal_a54362aaa0ea27f169880540e89568f39f50e82db6ec60cbecfb900c814f1973 = $this->env->getExtension("native_profiler");
        $__internal_a54362aaa0ea27f169880540e89568f39f50e82db6ec60cbecfb900c814f1973->enter($__internal_a54362aaa0ea27f169880540e89568f39f50e82db6ec60cbecfb900c814f1973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        echo "<header><p>HEADER</p></header>";
        
        $__internal_a54362aaa0ea27f169880540e89568f39f50e82db6ec60cbecfb900c814f1973->leave($__internal_a54362aaa0ea27f169880540e89568f39f50e82db6ec60cbecfb900c814f1973_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_84f2a0fa1a8c3d88003e5ba90c81210803cdf4775538afa902cf3c822b4f78b9 = $this->env->getExtension("native_profiler");
        $__internal_84f2a0fa1a8c3d88003e5ba90c81210803cdf4775538afa902cf3c822b4f78b9->enter($__internal_84f2a0fa1a8c3d88003e5ba90c81210803cdf4775538afa902cf3c822b4f78b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "        <div id=\"main\">
        \t ";
        // line 13
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

             ";
        // line 15
        $this->displayBlock('main', $context, $blocks);
        // line 16
        echo "        </div>
        ";
        
        $__internal_84f2a0fa1a8c3d88003e5ba90c81210803cdf4775538afa902cf3c822b4f78b9->leave($__internal_84f2a0fa1a8c3d88003e5ba90c81210803cdf4775538afa902cf3c822b4f78b9_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_b36fbff5ec0bbe6b18b124526c7d1c3fc706d25ab5e139e381881907d920d598 = $this->env->getExtension("native_profiler");
        $__internal_b36fbff5ec0bbe6b18b124526c7d1c3fc706d25ab5e139e381881907d920d598->enter($__internal_b36fbff5ec0bbe6b18b124526c7d1c3fc706d25ab5e139e381881907d920d598_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_b36fbff5ec0bbe6b18b124526c7d1c3fc706d25ab5e139e381881907d920d598->leave($__internal_b36fbff5ec0bbe6b18b124526c7d1c3fc706d25ab5e139e381881907d920d598_prof);

    }

    // line 18
    public function block_footer($context, array $blocks = array())
    {
        $__internal_7b9e28912e868de1c019f557f61f00dabd481536552b5099e92631244832f450 = $this->env->getExtension("native_profiler");
        $__internal_7b9e28912e868de1c019f557f61f00dabd481536552b5099e92631244832f450->enter($__internal_7b9e28912e868de1c019f557f61f00dabd481536552b5099e92631244832f450_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        echo "<footer><p>FOOTER</p></footer>";
        
        $__internal_7b9e28912e868de1c019f557f61f00dabd481536552b5099e92631244832f450->leave($__internal_7b9e28912e868de1c019f557f61f00dabd481536552b5099e92631244832f450_prof);

    }

    // line 19
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_33a429e3aa8040dcb66470bd5d41c453ddeaccb48d0d6fd9421acef907b677cc = $this->env->getExtension("native_profiler");
        $__internal_33a429e3aa8040dcb66470bd5d41c453ddeaccb48d0d6fd9421acef907b677cc->enter($__internal_33a429e3aa8040dcb66470bd5d41c453ddeaccb48d0d6fd9421acef907b677cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_33a429e3aa8040dcb66470bd5d41c453ddeaccb48d0d6fd9421acef907b677cc->leave($__internal_33a429e3aa8040dcb66470bd5d41c453ddeaccb48d0d6fd9421acef907b677cc_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 19,  138 => 18,  127 => 15,  119 => 16,  117 => 15,  112 => 13,  109 => 12,  103 => 11,  91 => 10,  80 => 6,  68 => 5,  59 => 20,  56 => 19,  53 => 18,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*     	{% block header %}<header><p>HEADER</p></header>{% endblock %}*/
/*         {% block body %}*/
/*         <div id="main">*/
/*         	 {{ include('default/_flash_messages.html.twig') }}*/
/* */
/*              {% block main %}{% endblock %}*/
/*         </div>*/
/*         {% endblock %}*/
/*         {% block footer %}<footer><p>FOOTER</p></footer>{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
