<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_5844269e597b2fe133d888b0af9cfd7cb21c7c88b15d55e47f5732f8334d2114 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1fa4a2a400268bd706084744b68e2b78a9b5ad9e5a586faa754c3f6bd4b67684 = $this->env->getExtension("native_profiler");
        $__internal_1fa4a2a400268bd706084744b68e2b78a9b5ad9e5a586faa754c3f6bd4b67684->enter($__internal_1fa4a2a400268bd706084744b68e2b78a9b5ad9e5a586faa754c3f6bd4b67684_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_1fa4a2a400268bd706084744b68e2b78a9b5ad9e5a586faa754c3f6bd4b67684->leave($__internal_1fa4a2a400268bd706084744b68e2b78a9b5ad9e5a586faa754c3f6bd4b67684_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
