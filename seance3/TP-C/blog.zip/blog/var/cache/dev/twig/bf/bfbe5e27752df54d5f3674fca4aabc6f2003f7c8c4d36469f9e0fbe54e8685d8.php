<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_5d1d4ed4df8e4dbf9843285f0554a97960d54d09ff9ecb059b6fa41f139a4e2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35270e5bb91c673dc39073753112a18deae16b23be1876c3909d50c2a08e6dc8 = $this->env->getExtension("native_profiler");
        $__internal_35270e5bb91c673dc39073753112a18deae16b23be1876c3909d50c2a08e6dc8->enter($__internal_35270e5bb91c673dc39073753112a18deae16b23be1876c3909d50c2a08e6dc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_35270e5bb91c673dc39073753112a18deae16b23be1876c3909d50c2a08e6dc8->leave($__internal_35270e5bb91c673dc39073753112a18deae16b23be1876c3909d50c2a08e6dc8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
