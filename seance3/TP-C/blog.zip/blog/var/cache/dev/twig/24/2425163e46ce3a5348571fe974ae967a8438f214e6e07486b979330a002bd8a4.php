<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_496ff7ae212eb915ef533bca4e79a9df1f12665fb6ae3c99ff589e59cbf97164 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f33b6dc42e22b1f69f57f4f8d627284aaabca6e1e3737973b6add5718469977e = $this->env->getExtension("native_profiler");
        $__internal_f33b6dc42e22b1f69f57f4f8d627284aaabca6e1e3737973b6add5718469977e->enter($__internal_f33b6dc42e22b1f69f57f4f8d627284aaabca6e1e3737973b6add5718469977e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_f33b6dc42e22b1f69f57f4f8d627284aaabca6e1e3737973b6add5718469977e->leave($__internal_f33b6dc42e22b1f69f57f4f8d627284aaabca6e1e3737973b6add5718469977e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
