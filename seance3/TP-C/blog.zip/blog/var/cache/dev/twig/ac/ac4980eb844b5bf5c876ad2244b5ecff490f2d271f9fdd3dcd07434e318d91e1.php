<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_8bc9e2f4597b97df0a5041e4d98ee5b4240b5da4662db7744c91168f54f4dbf3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d07059ef138e3bbaad8063b293d51f7f7ea82f339d0ae1f373808daae51f5bd = $this->env->getExtension("native_profiler");
        $__internal_2d07059ef138e3bbaad8063b293d51f7f7ea82f339d0ae1f373808daae51f5bd->enter($__internal_2d07059ef138e3bbaad8063b293d51f7f7ea82f339d0ae1f373808daae51f5bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_2d07059ef138e3bbaad8063b293d51f7f7ea82f339d0ae1f373808daae51f5bd->leave($__internal_2d07059ef138e3bbaad8063b293d51f7f7ea82f339d0ae1f373808daae51f5bd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
