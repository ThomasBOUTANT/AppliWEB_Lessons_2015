<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_f9f2981ef64dd7659dfbd00879cb6413adf5a3cf2c02ec6dd0462bba08b9286f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1ed72a7fe2c3f8520714f6bc03cc82e842859d88f8e9c0c119fcfd95b6d7f4f = $this->env->getExtension("native_profiler");
        $__internal_a1ed72a7fe2c3f8520714f6bc03cc82e842859d88f8e9c0c119fcfd95b6d7f4f->enter($__internal_a1ed72a7fe2c3f8520714f6bc03cc82e842859d88f8e9c0c119fcfd95b6d7f4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_a1ed72a7fe2c3f8520714f6bc03cc82e842859d88f8e9c0c119fcfd95b6d7f4f->leave($__internal_a1ed72a7fe2c3f8520714f6bc03cc82e842859d88f8e9c0c119fcfd95b6d7f4f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
