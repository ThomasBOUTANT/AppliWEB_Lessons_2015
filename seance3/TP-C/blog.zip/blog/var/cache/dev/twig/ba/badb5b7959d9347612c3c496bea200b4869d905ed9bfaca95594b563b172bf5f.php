<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_ecb1b2475cf74e35ccab1fa221ff88ca50721aa2bc605e72c881d372293b8b15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58c33e563c0fcef81e0e81ccdc42216b10c1ce71259b333ac13b516059b608a4 = $this->env->getExtension("native_profiler");
        $__internal_58c33e563c0fcef81e0e81ccdc42216b10c1ce71259b333ac13b516059b608a4->enter($__internal_58c33e563c0fcef81e0e81ccdc42216b10c1ce71259b333ac13b516059b608a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_58c33e563c0fcef81e0e81ccdc42216b10c1ce71259b333ac13b516059b608a4->leave($__internal_58c33e563c0fcef81e0e81ccdc42216b10c1ce71259b333ac13b516059b608a4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
