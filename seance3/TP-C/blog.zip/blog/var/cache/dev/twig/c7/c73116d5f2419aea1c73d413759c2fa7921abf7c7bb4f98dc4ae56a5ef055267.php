<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_1e8cf1c658d938646e9f0adbefa0e361c1cbdced873c5b66e3beb95e302323d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_465c5771dabf78e17d8f7810da82342f4942a77a2814b9ad876085191fcb0304 = $this->env->getExtension("native_profiler");
        $__internal_465c5771dabf78e17d8f7810da82342f4942a77a2814b9ad876085191fcb0304->enter($__internal_465c5771dabf78e17d8f7810da82342f4942a77a2814b9ad876085191fcb0304_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_465c5771dabf78e17d8f7810da82342f4942a77a2814b9ad876085191fcb0304->leave($__internal_465c5771dabf78e17d8f7810da82342f4942a77a2814b9ad876085191fcb0304_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
