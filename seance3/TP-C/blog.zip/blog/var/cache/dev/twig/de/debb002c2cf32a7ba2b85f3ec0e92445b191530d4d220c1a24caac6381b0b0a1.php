<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_6b7f47affafa1f2a27ab2bd8f8643592d1b898ad7b0adc1956b0300de2e36695 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e1233e21a7ed9068f54b8a8a09bd746ae877cf0a042e7e6ef7b006a27582bad = $this->env->getExtension("native_profiler");
        $__internal_0e1233e21a7ed9068f54b8a8a09bd746ae877cf0a042e7e6ef7b006a27582bad->enter($__internal_0e1233e21a7ed9068f54b8a8a09bd746ae877cf0a042e7e6ef7b006a27582bad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_user_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
    <p>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_0e1233e21a7ed9068f54b8a8a09bd746ae877cf0a042e7e6ef7b006a27582bad->leave($__internal_0e1233e21a7ed9068f54b8a8a09bd746ae877cf0a042e7e6ef7b006a27582bad_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 5,  26 => 4,  22 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* <div class="fos_user_user_show">*/
/*     <p>{{ 'profile.show.username'|trans }}: {{ user.username }}</p>*/
/*     <p>{{ 'profile.show.email'|trans }}: {{ user.email }}</p>*/
/* </div>*/
/* */
