<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_72764bf8177ad006eec4acf58ca5857b5990a47463d566b99b4b38571f66d8b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc4cc892bf9cdf2dd5d463020a4d5530a3d61e0f3fa3a215eaedf36f8d6a3053 = $this->env->getExtension("native_profiler");
        $__internal_fc4cc892bf9cdf2dd5d463020a4d5530a3d61e0f3fa3a215eaedf36f8d6a3053->enter($__internal_fc4cc892bf9cdf2dd5d463020a4d5530a3d61e0f3fa3a215eaedf36f8d6a3053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_fc4cc892bf9cdf2dd5d463020a4d5530a3d61e0f3fa3a215eaedf36f8d6a3053->leave($__internal_fc4cc892bf9cdf2dd5d463020a4d5530a3d61e0f3fa3a215eaedf36f8d6a3053_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
