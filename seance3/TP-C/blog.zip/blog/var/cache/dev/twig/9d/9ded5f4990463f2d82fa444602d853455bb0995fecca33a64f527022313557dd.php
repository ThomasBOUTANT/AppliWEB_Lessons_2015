<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_be359517d4b00652a79ec09110379b974bcf604c5ff72b0c976f6f59a5902727 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2237f2aff3006cf7d77e3f3a3e35a422febaa0c945b382263ee428a9358891d7 = $this->env->getExtension("native_profiler");
        $__internal_2237f2aff3006cf7d77e3f3a3e35a422febaa0c945b382263ee428a9358891d7->enter($__internal_2237f2aff3006cf7d77e3f3a3e35a422febaa0c945b382263ee428a9358891d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_2237f2aff3006cf7d77e3f3a3e35a422febaa0c945b382263ee428a9358891d7->leave($__internal_2237f2aff3006cf7d77e3f3a3e35a422febaa0c945b382263ee428a9358891d7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child) : ?>*/
/*     <?php echo $view['form']->row($child) ?>*/
/* <?php endforeach; ?>*/
/* */
