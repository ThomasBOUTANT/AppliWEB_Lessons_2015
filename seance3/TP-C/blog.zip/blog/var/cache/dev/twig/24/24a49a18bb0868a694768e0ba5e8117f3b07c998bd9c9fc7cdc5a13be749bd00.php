<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_f40ce04e862697c6450cfa1fc7388dd303f0813003a4bed1be2e896aaa929c5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_748fd4f24c54c2dccc51d0405f95b87dfc44ffa74745715c62c9f4e55e14f9ee = $this->env->getExtension("native_profiler");
        $__internal_748fd4f24c54c2dccc51d0405f95b87dfc44ffa74745715c62c9f4e55e14f9ee->enter($__internal_748fd4f24c54c2dccc51d0405f95b87dfc44ffa74745715c62c9f4e55e14f9ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_748fd4f24c54c2dccc51d0405f95b87dfc44ffa74745715c62c9f4e55e14f9ee->leave($__internal_748fd4f24c54c2dccc51d0405f95b87dfc44ffa74745715c62c9f4e55e14f9ee_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_75f4a4cbe4cb3de5389b97a93480293df13844b69010aa0ea1c18452e827a2d2 = $this->env->getExtension("native_profiler");
        $__internal_75f4a4cbe4cb3de5389b97a93480293df13844b69010aa0ea1c18452e827a2d2->enter($__internal_75f4a4cbe4cb3de5389b97a93480293df13844b69010aa0ea1c18452e827a2d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "FOSUserBundle:Security:login_content.html.twig");
        echo "
";
        
        $__internal_75f4a4cbe4cb3de5389b97a93480293df13844b69010aa0ea1c18452e827a2d2->leave($__internal_75f4a4cbe4cb3de5389b97a93480293df13844b69010aa0ea1c18452e827a2d2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/*     {{ include('FOSUserBundle:Security:login_content.html.twig') }}*/
/* {% endblock fos_user_content %}*/
/* */
