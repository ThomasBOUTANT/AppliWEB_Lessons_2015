<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_fe66f81b6efd328e4ef86701af644299fa65063816f8624c0941f9be321f50e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a655de8f35c21ce1dd4ec1dbbc65a9ed15b02c8c081b4166b20f62111470610 = $this->env->getExtension("native_profiler");
        $__internal_4a655de8f35c21ce1dd4ec1dbbc65a9ed15b02c8c081b4166b20f62111470610->enter($__internal_4a655de8f35c21ce1dd4ec1dbbc65a9ed15b02c8c081b4166b20f62111470610_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_4a655de8f35c21ce1dd4ec1dbbc65a9ed15b02c8c081b4166b20f62111470610->leave($__internal_4a655de8f35c21ce1dd4ec1dbbc65a9ed15b02c8c081b4166b20f62111470610_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
