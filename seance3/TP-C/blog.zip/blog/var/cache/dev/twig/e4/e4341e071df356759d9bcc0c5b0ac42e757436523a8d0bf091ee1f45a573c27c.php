<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_ecf1dbdd0efadaee64603048a07bceef0650ea2b956c237bceaf5fb17358eda1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af8b92a1a5d74e9b297770a283a9909349802b085f1d6905023976a3e81750a9 = $this->env->getExtension("native_profiler");
        $__internal_af8b92a1a5d74e9b297770a283a9909349802b085f1d6905023976a3e81750a9->enter($__internal_af8b92a1a5d74e9b297770a283a9909349802b085f1d6905023976a3e81750a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_af8b92a1a5d74e9b297770a283a9909349802b085f1d6905023976a3e81750a9->leave($__internal_af8b92a1a5d74e9b297770a283a9909349802b085f1d6905023976a3e81750a9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
