<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_b8e72e0b281e9bf44e62e39b9cee408518708a733af32bb21bc93ad999e51325 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52d4fbe7184e5d89004919a3f10f5d1527a2fd2d810736c031479d0f4b99db89 = $this->env->getExtension("native_profiler");
        $__internal_52d4fbe7184e5d89004919a3f10f5d1527a2fd2d810736c031479d0f4b99db89->enter($__internal_52d4fbe7184e5d89004919a3f10f5d1527a2fd2d810736c031479d0f4b99db89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_52d4fbe7184e5d89004919a3f10f5d1527a2fd2d810736c031479d0f4b99db89->leave($__internal_52d4fbe7184e5d89004919a3f10f5d1527a2fd2d810736c031479d0f4b99db89_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_81cddf885e61e065d33706a368f25b4e6bdfabfa5e5c68b9f6447a6f0003a066 = $this->env->getExtension("native_profiler");
        $__internal_81cddf885e61e065d33706a368f25b4e6bdfabfa5e5c68b9f6447a6f0003a066->enter($__internal_81cddf885e61e065d33706a368f25b4e6bdfabfa5e5c68b9f6447a6f0003a066_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_81cddf885e61e065d33706a368f25b4e6bdfabfa5e5c68b9f6447a6f0003a066->leave($__internal_81cddf885e61e065d33706a368f25b4e6bdfabfa5e5c68b9f6447a6f0003a066_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
