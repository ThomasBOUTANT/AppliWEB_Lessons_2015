<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_6fd8f597cb2a8fd38c6078997539c03a17689858743c05370f6cacb1811be747 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_993a6e4525aca44348c350b67a6d2a8e78b604a32fc919a8879b57a4759baa97 = $this->env->getExtension("native_profiler");
        $__internal_993a6e4525aca44348c350b67a6d2a8e78b604a32fc919a8879b57a4759baa97->enter($__internal_993a6e4525aca44348c350b67a6d2a8e78b604a32fc919a8879b57a4759baa97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_993a6e4525aca44348c350b67a6d2a8e78b604a32fc919a8879b57a4759baa97->leave($__internal_993a6e4525aca44348c350b67a6d2a8e78b604a32fc919a8879b57a4759baa97_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
