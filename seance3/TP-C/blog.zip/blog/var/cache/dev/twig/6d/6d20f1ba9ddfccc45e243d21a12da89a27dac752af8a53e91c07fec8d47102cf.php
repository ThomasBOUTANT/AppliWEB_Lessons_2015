<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_93be269f16a71607d70c6f6c5863729c8f64b0369b13163a563eb405ec2c016b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d1e00104750784b44539f8a3ed8347220d563993dc56061a58c3ff510028725 = $this->env->getExtension("native_profiler");
        $__internal_2d1e00104750784b44539f8a3ed8347220d563993dc56061a58c3ff510028725->enter($__internal_2d1e00104750784b44539f8a3ed8347220d563993dc56061a58c3ff510028725_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2d1e00104750784b44539f8a3ed8347220d563993dc56061a58c3ff510028725->leave($__internal_2d1e00104750784b44539f8a3ed8347220d563993dc56061a58c3ff510028725_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_5371d7a9c0b07dec0b4d74df83376db14fef4735c56a8371023b98bd538541db = $this->env->getExtension("native_profiler");
        $__internal_5371d7a9c0b07dec0b4d74df83376db14fef4735c56a8371023b98bd538541db->enter($__internal_5371d7a9c0b07dec0b4d74df83376db14fef4735c56a8371023b98bd538541db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_5371d7a9c0b07dec0b4d74df83376db14fef4735c56a8371023b98bd538541db->leave($__internal_5371d7a9c0b07dec0b4d74df83376db14fef4735c56a8371023b98bd538541db_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
