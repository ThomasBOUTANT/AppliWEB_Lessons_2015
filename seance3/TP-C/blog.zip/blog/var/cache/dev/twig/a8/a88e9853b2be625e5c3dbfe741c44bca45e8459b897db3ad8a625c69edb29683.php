<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_f163df009decc13d623374e081cd26b7b7be4e296a908cb7536c7f5b22ea90a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79f08c852f497cd33e29daac14eab4ec227e93cd29f4f80a4c3a5954523fde6f = $this->env->getExtension("native_profiler");
        $__internal_79f08c852f497cd33e29daac14eab4ec227e93cd29f4f80a4c3a5954523fde6f->enter($__internal_79f08c852f497cd33e29daac14eab4ec227e93cd29f4f80a4c3a5954523fde6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_79f08c852f497cd33e29daac14eab4ec227e93cd29f4f80a4c3a5954523fde6f->leave($__internal_79f08c852f497cd33e29daac14eab4ec227e93cd29f4f80a4c3a5954523fde6f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
