<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_7874270e746b530cea74aab7416fc3fd21b594263a2199b8043d4f695cc4ebd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_baec1333f52817acb0fceb3ee939410ab4e685977cad7656d3bc5d9834d3cf42 = $this->env->getExtension("native_profiler");
        $__internal_baec1333f52817acb0fceb3ee939410ab4e685977cad7656d3bc5d9834d3cf42->enter($__internal_baec1333f52817acb0fceb3ee939410ab4e685977cad7656d3bc5d9834d3cf42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_baec1333f52817acb0fceb3ee939410ab4e685977cad7656d3bc5d9834d3cf42->leave($__internal_baec1333f52817acb0fceb3ee939410ab4e685977cad7656d3bc5d9834d3cf42_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
