<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_5ffa06a3b9b0cf4b54dee4c85e0585174bc1f822bfac21c7001c3f4d478c8de4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e646e7301fb7273c4a3c0654b5f35d7d83909f56ffe0ab45b90d48e05411b8dd = $this->env->getExtension("native_profiler");
        $__internal_e646e7301fb7273c4a3c0654b5f35d7d83909f56ffe0ab45b90d48e05411b8dd->enter($__internal_e646e7301fb7273c4a3c0654b5f35d7d83909f56ffe0ab45b90d48e05411b8dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e646e7301fb7273c4a3c0654b5f35d7d83909f56ffe0ab45b90d48e05411b8dd->leave($__internal_e646e7301fb7273c4a3c0654b5f35d7d83909f56ffe0ab45b90d48e05411b8dd_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cf4377a02d255a7a458a2cdad2a6abdb04f762c28ba257ef5d87c9afa2d4ab81 = $this->env->getExtension("native_profiler");
        $__internal_cf4377a02d255a7a458a2cdad2a6abdb04f762c28ba257ef5d87c9afa2d4ab81->enter($__internal_cf4377a02d255a7a458a2cdad2a6abdb04f762c28ba257ef5d87c9afa2d4ab81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_cf4377a02d255a7a458a2cdad2a6abdb04f762c28ba257ef5d87c9afa2d4ab81->leave($__internal_cf4377a02d255a7a458a2cdad2a6abdb04f762c28ba257ef5d87c9afa2d4ab81_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
