<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_465e16fc791df6e3c81ee76f84a21b009fdd806225f5043e6a60f88dd5d4cf4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d74b7ef548febc7e182e4dfccf11d61764e76803502399520a9e0e9cdf507af = $this->env->getExtension("native_profiler");
        $__internal_9d74b7ef548febc7e182e4dfccf11d61764e76803502399520a9e0e9cdf507af->enter($__internal_9d74b7ef548febc7e182e4dfccf11d61764e76803502399520a9e0e9cdf507af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_9d74b7ef548febc7e182e4dfccf11d61764e76803502399520a9e0e9cdf507af->leave($__internal_9d74b7ef548febc7e182e4dfccf11d61764e76803502399520a9e0e9cdf507af_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
