<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_3cd1d3815f292625c15a6f24ca1fff9c30086df95d604b2bbd93c688e455cd74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_226a5481921e7a2d79c432275554c8b85a888058fd5cdcade3385f3c339ddcd9 = $this->env->getExtension("native_profiler");
        $__internal_226a5481921e7a2d79c432275554c8b85a888058fd5cdcade3385f3c339ddcd9->enter($__internal_226a5481921e7a2d79c432275554c8b85a888058fd5cdcade3385f3c339ddcd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_226a5481921e7a2d79c432275554c8b85a888058fd5cdcade3385f3c339ddcd9->leave($__internal_226a5481921e7a2d79c432275554c8b85a888058fd5cdcade3385f3c339ddcd9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
