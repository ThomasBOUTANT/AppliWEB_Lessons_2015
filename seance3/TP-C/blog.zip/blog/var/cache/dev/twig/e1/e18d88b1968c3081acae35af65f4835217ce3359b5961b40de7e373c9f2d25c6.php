<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_af050b499d0ac73330a8a12ba9c4eda7e0697b3eeaa999798fbfec5aa87a80b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b1a41908daa120885d565a5b9847f11ac4939aee4d2d73049beb36f06e40a1d = $this->env->getExtension("native_profiler");
        $__internal_9b1a41908daa120885d565a5b9847f11ac4939aee4d2d73049beb36f06e40a1d->enter($__internal_9b1a41908daa120885d565a5b9847f11ac4939aee4d2d73049beb36f06e40a1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_9b1a41908daa120885d565a5b9847f11ac4939aee4d2d73049beb36f06e40a1d->leave($__internal_9b1a41908daa120885d565a5b9847f11ac4939aee4d2d73049beb36f06e40a1d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
