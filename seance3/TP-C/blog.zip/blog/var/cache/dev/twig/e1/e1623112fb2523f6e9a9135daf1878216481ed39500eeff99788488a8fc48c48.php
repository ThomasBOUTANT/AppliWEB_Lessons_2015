<?php

/* FOSUserBundle:Resetting:check_email.html.twig */
class __TwigTemplate_a95da54fc8ae5d6ef88c067fc740774b93c072129b88091f75ead3d9c9d1a5d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dbdbd91dd6939553db7a0021af15796433af3b1847ba6efa60d92bd9ae1b733d = $this->env->getExtension("native_profiler");
        $__internal_dbdbd91dd6939553db7a0021af15796433af3b1847ba6efa60d92bd9ae1b733d->enter($__internal_dbdbd91dd6939553db7a0021af15796433af3b1847ba6efa60d92bd9ae1b733d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dbdbd91dd6939553db7a0021af15796433af3b1847ba6efa60d92bd9ae1b733d->leave($__internal_dbdbd91dd6939553db7a0021af15796433af3b1847ba6efa60d92bd9ae1b733d_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4da263ccca93c26f71965b93a73b9e047a59562341bae9e9e3030ea8919410ba = $this->env->getExtension("native_profiler");
        $__internal_4da263ccca93c26f71965b93a73b9e047a59562341bae9e9e3030ea8919410ba->enter($__internal_4da263ccca93c26f71965b93a73b9e047a59562341bae9e9e3030ea8919410ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_4da263ccca93c26f71965b93a73b9e047a59562341bae9e9e3030ea8919410ba->leave($__internal_4da263ccca93c26f71965b93a73b9e047a59562341bae9e9e3030ea8919410ba_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
