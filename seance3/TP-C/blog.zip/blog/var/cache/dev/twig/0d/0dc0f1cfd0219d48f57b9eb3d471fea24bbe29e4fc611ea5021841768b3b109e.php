<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_de06256b53f2156b1c242e7e5f6dcfa234c47ef3470e269fc1119502d1693fb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9217104960706da838456ecce5c00dd55173ce6ac4d018719c04f6ec252ce69c = $this->env->getExtension("native_profiler");
        $__internal_9217104960706da838456ecce5c00dd55173ce6ac4d018719c04f6ec252ce69c->enter($__internal_9217104960706da838456ecce5c00dd55173ce6ac4d018719c04f6ec252ce69c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_9217104960706da838456ecce5c00dd55173ce6ac4d018719c04f6ec252ce69c->leave($__internal_9217104960706da838456ecce5c00dd55173ce6ac4d018719c04f6ec252ce69c_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_6f957a13f6817434be318a5f1d46a4bfa7f6b3b0f689547039d57581eb26519c = $this->env->getExtension("native_profiler");
        $__internal_6f957a13f6817434be318a5f1d46a4bfa7f6b3b0f689547039d57581eb26519c->enter($__internal_6f957a13f6817434be318a5f1d46a4bfa7f6b3b0f689547039d57581eb26519c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_6f957a13f6817434be318a5f1d46a4bfa7f6b3b0f689547039d57581eb26519c->leave($__internal_6f957a13f6817434be318a5f1d46a4bfa7f6b3b0f689547039d57581eb26519c_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_7f23929062c91e62ac3c9a9b81cde442acea19a4ed8ff399f1b7f06777867046 = $this->env->getExtension("native_profiler");
        $__internal_7f23929062c91e62ac3c9a9b81cde442acea19a4ed8ff399f1b7f06777867046->enter($__internal_7f23929062c91e62ac3c9a9b81cde442acea19a4ed8ff399f1b7f06777867046_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_7f23929062c91e62ac3c9a9b81cde442acea19a4ed8ff399f1b7f06777867046->leave($__internal_7f23929062c91e62ac3c9a9b81cde442acea19a4ed8ff399f1b7f06777867046_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_c6d7e8a7e90d74a343d63e902fba0d834358162ae766a083747f8c1473cde2ba = $this->env->getExtension("native_profiler");
        $__internal_c6d7e8a7e90d74a343d63e902fba0d834358162ae766a083747f8c1473cde2ba->enter($__internal_c6d7e8a7e90d74a343d63e902fba0d834358162ae766a083747f8c1473cde2ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_c6d7e8a7e90d74a343d63e902fba0d834358162ae766a083747f8c1473cde2ba->leave($__internal_c6d7e8a7e90d74a343d63e902fba0d834358162ae766a083747f8c1473cde2ba_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
