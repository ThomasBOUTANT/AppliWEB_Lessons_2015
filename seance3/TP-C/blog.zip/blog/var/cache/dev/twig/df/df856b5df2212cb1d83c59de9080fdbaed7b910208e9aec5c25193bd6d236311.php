<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_6aa291610304c2b1da62fba67d55b86f7f2be729ee72ad2fdad68b9498dd4d67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e29c14577b192f7ecfd66d31791021f3c2365074b102bcb89c5bf1e7b7bc09b2 = $this->env->getExtension("native_profiler");
        $__internal_e29c14577b192f7ecfd66d31791021f3c2365074b102bcb89c5bf1e7b7bc09b2->enter($__internal_e29c14577b192f7ecfd66d31791021f3c2365074b102bcb89c5bf1e7b7bc09b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e29c14577b192f7ecfd66d31791021f3c2365074b102bcb89c5bf1e7b7bc09b2->leave($__internal_e29c14577b192f7ecfd66d31791021f3c2365074b102bcb89c5bf1e7b7bc09b2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d3efe58080d3d3e3686d6a67faa5a65f2b2512a34ff54cf5f9233e5a1b403c94 = $this->env->getExtension("native_profiler");
        $__internal_d3efe58080d3d3e3686d6a67faa5a65f2b2512a34ff54cf5f9233e5a1b403c94->enter($__internal_d3efe58080d3d3e3686d6a67faa5a65f2b2512a34ff54cf5f9233e5a1b403c94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_d3efe58080d3d3e3686d6a67faa5a65f2b2512a34ff54cf5f9233e5a1b403c94->leave($__internal_d3efe58080d3d3e3686d6a67faa5a65f2b2512a34ff54cf5f9233e5a1b403c94_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
