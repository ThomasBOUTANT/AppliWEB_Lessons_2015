<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_f0f78d3a81bbc3faf0ed7d6cd0fdcc60c1fb789d5ff64254979c18be675e5e73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ec32672552bc50d23fe78e68bc0d0eab91235bdc87820a2c4019b8904255d3f = $this->env->getExtension("native_profiler");
        $__internal_8ec32672552bc50d23fe78e68bc0d0eab91235bdc87820a2c4019b8904255d3f->enter($__internal_8ec32672552bc50d23fe78e68bc0d0eab91235bdc87820a2c4019b8904255d3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_8ec32672552bc50d23fe78e68bc0d0eab91235bdc87820a2c4019b8904255d3f->leave($__internal_8ec32672552bc50d23fe78e68bc0d0eab91235bdc87820a2c4019b8904255d3f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
