<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_40756d035944421884ba2abf7c6fe316bf30f7ef8057ddc00f3cdfc1f67e471b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c73a8a08801f3e5e2b2447890d8b685bbbd836ff65f7704f7367333157d74fb5 = $this->env->getExtension("native_profiler");
        $__internal_c73a8a08801f3e5e2b2447890d8b685bbbd836ff65f7704f7367333157d74fb5->enter($__internal_c73a8a08801f3e5e2b2447890d8b685bbbd836ff65f7704f7367333157d74fb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c73a8a08801f3e5e2b2447890d8b685bbbd836ff65f7704f7367333157d74fb5->leave($__internal_c73a8a08801f3e5e2b2447890d8b685bbbd836ff65f7704f7367333157d74fb5_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_376ef7580cf5a7187c1fc8ce18abedc491b38646aa44a9121667b0ed0b139322 = $this->env->getExtension("native_profiler");
        $__internal_376ef7580cf5a7187c1fc8ce18abedc491b38646aa44a9121667b0ed0b139322->enter($__internal_376ef7580cf5a7187c1fc8ce18abedc491b38646aa44a9121667b0ed0b139322_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_376ef7580cf5a7187c1fc8ce18abedc491b38646aa44a9121667b0ed0b139322->leave($__internal_376ef7580cf5a7187c1fc8ce18abedc491b38646aa44a9121667b0ed0b139322_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
