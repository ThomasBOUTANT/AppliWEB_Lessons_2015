<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_7b9c1764d4508e5cecb6da3c83b9770b94f82eb92e7c64958d3033e1f5b70d67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_890f159102e90f48647476ce213984051d78240ea911724f693e1f8d1c734875 = $this->env->getExtension("native_profiler");
        $__internal_890f159102e90f48647476ce213984051d78240ea911724f693e1f8d1c734875->enter($__internal_890f159102e90f48647476ce213984051d78240ea911724f693e1f8d1c734875_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_890f159102e90f48647476ce213984051d78240ea911724f693e1f8d1c734875->leave($__internal_890f159102e90f48647476ce213984051d78240ea911724f693e1f8d1c734875_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_bdf0141438db5f08b458d51c52c6dd97b2340d7fc607e13b0ac748e16ef1335e = $this->env->getExtension("native_profiler");
        $__internal_bdf0141438db5f08b458d51c52c6dd97b2340d7fc607e13b0ac748e16ef1335e->enter($__internal_bdf0141438db5f08b458d51c52c6dd97b2340d7fc607e13b0ac748e16ef1335e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_bdf0141438db5f08b458d51c52c6dd97b2340d7fc607e13b0ac748e16ef1335e->leave($__internal_bdf0141438db5f08b458d51c52c6dd97b2340d7fc607e13b0ac748e16ef1335e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
