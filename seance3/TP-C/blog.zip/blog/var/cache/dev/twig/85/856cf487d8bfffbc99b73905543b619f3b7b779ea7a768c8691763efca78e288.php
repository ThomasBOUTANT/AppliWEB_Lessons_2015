<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_510cdddac2f8105d7b19d8208e7b3d643f74c0acb111c33ecea401c499119f51 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_862b28050b5591a113a6d707460839cc728148d13fae6043825a6bf397b54720 = $this->env->getExtension("native_profiler");
        $__internal_862b28050b5591a113a6d707460839cc728148d13fae6043825a6bf397b54720->enter($__internal_862b28050b5591a113a6d707460839cc728148d13fae6043825a6bf397b54720_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_862b28050b5591a113a6d707460839cc728148d13fae6043825a6bf397b54720->leave($__internal_862b28050b5591a113a6d707460839cc728148d13fae6043825a6bf397b54720_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
