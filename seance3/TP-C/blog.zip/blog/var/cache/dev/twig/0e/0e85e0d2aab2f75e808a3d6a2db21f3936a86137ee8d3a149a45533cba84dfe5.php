<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_d5d043f4a69d0adca41754f07577d3669af415033c0da8d7d402fc42ae807492 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45ea468a13981f507617b1622fe3bf981aedd71c6afc4831df785d8020758f19 = $this->env->getExtension("native_profiler");
        $__internal_45ea468a13981f507617b1622fe3bf981aedd71c6afc4831df785d8020758f19->enter($__internal_45ea468a13981f507617b1622fe3bf981aedd71c6afc4831df785d8020758f19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_45ea468a13981f507617b1622fe3bf981aedd71c6afc4831df785d8020758f19->leave($__internal_45ea468a13981f507617b1622fe3bf981aedd71c6afc4831df785d8020758f19_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
