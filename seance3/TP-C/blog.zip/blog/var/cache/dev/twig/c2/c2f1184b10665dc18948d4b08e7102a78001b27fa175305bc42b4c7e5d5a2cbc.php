<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_2b32e9131f9f9e1c2514df3c463dc88e4e1461ee3627476e00ba8bf06f7546a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aae16d101ca281c7e343ac4fe6474b3fcda97bb643f8848bc71c605ba0248717 = $this->env->getExtension("native_profiler");
        $__internal_aae16d101ca281c7e343ac4fe6474b3fcda97bb643f8848bc71c605ba0248717->enter($__internal_aae16d101ca281c7e343ac4fe6474b3fcda97bb643f8848bc71c605ba0248717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_aae16d101ca281c7e343ac4fe6474b3fcda97bb643f8848bc71c605ba0248717->leave($__internal_aae16d101ca281c7e343ac4fe6474b3fcda97bb643f8848bc71c605ba0248717_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
