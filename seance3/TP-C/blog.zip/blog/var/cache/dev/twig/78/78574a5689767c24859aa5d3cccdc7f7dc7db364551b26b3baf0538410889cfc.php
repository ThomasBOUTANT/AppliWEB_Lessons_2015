<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_ee8d7a60f9289eaeacff606d0160c10d1d569a024c1ea5c7946a49b8c7727ccd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc610c1782bddb45a965de90d3e42da1374ad07d3d9e9932ae64f859b32367c6 = $this->env->getExtension("native_profiler");
        $__internal_dc610c1782bddb45a965de90d3e42da1374ad07d3d9e9932ae64f859b32367c6->enter($__internal_dc610c1782bddb45a965de90d3e42da1374ad07d3d9e9932ae64f859b32367c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_dc610c1782bddb45a965de90d3e42da1374ad07d3d9e9932ae64f859b32367c6->leave($__internal_dc610c1782bddb45a965de90d3e42da1374ad07d3d9e9932ae64f859b32367c6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
