<?php

/* :blog:show.html.twig */
class __TwigTemplate_bf856734370a1cf561d136ef1dfdcc7f7c9211b17a3e79a69ba0cbca549d83c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("blog/blogbase.html.twig", ":blog:show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "blog/blogbase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_163a9ce8de348e5196585268008107c0e4ad619f832ca7869228e2c4870f266a = $this->env->getExtension("native_profiler");
        $__internal_163a9ce8de348e5196585268008107c0e4ad619f832ca7869228e2c4870f266a->enter($__internal_163a9ce8de348e5196585268008107c0e4ad619f832ca7869228e2c4870f266a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_163a9ce8de348e5196585268008107c0e4ad619f832ca7869228e2c4870f266a->leave($__internal_163a9ce8de348e5196585268008107c0e4ad619f832ca7869228e2c4870f266a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_98bac497a1c1ac049fddcf515f3bd2b6a08bf83492fdbf4ab8a9a0b21e62c570 = $this->env->getExtension("native_profiler");
        $__internal_98bac497a1c1ac049fddcf515f3bd2b6a08bf83492fdbf4ab8a9a0b21e62c570->enter($__internal_98bac497a1c1ac049fddcf515f3bd2b6a08bf83492fdbf4ab8a9a0b21e62c570_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        
        $__internal_98bac497a1c1ac049fddcf515f3bd2b6a08bf83492fdbf4ab8a9a0b21e62c570->leave($__internal_98bac497a1c1ac049fddcf515f3bd2b6a08bf83492fdbf4ab8a9a0b21e62c570_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_4bb7b1519db700ea3c45d3d5c1c9fb5fc3d1d9663406db28d9bc4671c3458fa9 = $this->env->getExtension("native_profiler");
        $__internal_4bb7b1519db700ea3c45d3d5c1c9fb5fc3d1d9663406db28d9bc4671c3458fa9->enter($__internal_4bb7b1519db700ea3c45d3d5c1c9fb5fc3d1d9663406db28d9bc4671c3458fa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h1>
    
    <div class=\"date\">";
        // line 8
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "publishedAt", array()), "medium", "short", null, "UTC"), "html", null, true);
        echo "</div>
    <div class=\"body\">
        ";
        // line 10
        echo $this->env->getExtension('app.extension')->markdownToHtml($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "content", array()));
        echo "
    </div>
";
        
        $__internal_4bb7b1519db700ea3c45d3d5c1c9fb5fc3d1d9663406db28d9bc4671c3458fa9->leave($__internal_4bb7b1519db700ea3c45d3d5c1c9fb5fc3d1d9663406db28d9bc4671c3458fa9_prof);

    }

    public function getTemplateName()
    {
        return ":blog:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 10,  59 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'blog/blogbase.html.twig' %}*/
/* */
/* {% block title %}{{ post.title }}{% endblock %}*/
/* */
/* {% block main %}*/
/*     <h1>{{ post.title }}</h1>*/
/*     */
/*     <div class="date">{{ post.publishedAt|localizeddate('medium', 'short', null, 'UTC') }}</div>*/
/*     <div class="body">*/
/*         {{ post.content|md2html }}*/
/*     </div>*/
/* {% endblock %}*/
/* */
