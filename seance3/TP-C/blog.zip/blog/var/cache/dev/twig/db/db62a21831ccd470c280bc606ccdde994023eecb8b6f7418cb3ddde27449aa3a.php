<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_56c5f06d5053c50608422604ce539f9c0203317e66fb38354a1a5ddf15d28617 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20b388164e4024615426cf2a5fd390d8ddb08a88cdb3a6c38c5dac2dbfdd7946 = $this->env->getExtension("native_profiler");
        $__internal_20b388164e4024615426cf2a5fd390d8ddb08a88cdb3a6c38c5dac2dbfdd7946->enter($__internal_20b388164e4024615426cf2a5fd390d8ddb08a88cdb3a6c38c5dac2dbfdd7946_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_20b388164e4024615426cf2a5fd390d8ddb08a88cdb3a6c38c5dac2dbfdd7946->leave($__internal_20b388164e4024615426cf2a5fd390d8ddb08a88cdb3a6c38c5dac2dbfdd7946_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
