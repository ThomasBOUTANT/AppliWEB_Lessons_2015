<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_7006a7aa1f13fbcc91b7238c6ef4dce320155cef442e549737251f51074dcf57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_09e29335b960a7c447161c37883da3fee773b9c4ebd55280975cbdf07c286649 = $this->env->getExtension("native_profiler");
        $__internal_09e29335b960a7c447161c37883da3fee773b9c4ebd55280975cbdf07c286649->enter($__internal_09e29335b960a7c447161c37883da3fee773b9c4ebd55280975cbdf07c286649_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_09e29335b960a7c447161c37883da3fee773b9c4ebd55280975cbdf07c286649->leave($__internal_09e29335b960a7c447161c37883da3fee773b9c4ebd55280975cbdf07c286649_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_19293e8af993fdd8580f32ca6f384ed16f0372cc1a2548bccfd724b6f461b8fa = $this->env->getExtension("native_profiler");
        $__internal_19293e8af993fdd8580f32ca6f384ed16f0372cc1a2548bccfd724b6f461b8fa->enter($__internal_19293e8af993fdd8580f32ca6f384ed16f0372cc1a2548bccfd724b6f461b8fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_19293e8af993fdd8580f32ca6f384ed16f0372cc1a2548bccfd724b6f461b8fa->leave($__internal_19293e8af993fdd8580f32ca6f384ed16f0372cc1a2548bccfd724b6f461b8fa_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
