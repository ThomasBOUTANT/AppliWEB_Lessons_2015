<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_0b8a3f161b29500245f324c23d19d3d2f169cf0784c254a5bbf45ff97da1fe3d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10d8528bdd0cc587fbae6784037e5bad926d669cf5aeb043f87f2bbec0a5b8b2 = $this->env->getExtension("native_profiler");
        $__internal_10d8528bdd0cc587fbae6784037e5bad926d669cf5aeb043f87f2bbec0a5b8b2->enter($__internal_10d8528bdd0cc587fbae6784037e5bad926d669cf5aeb043f87f2bbec0a5b8b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_10d8528bdd0cc587fbae6784037e5bad926d669cf5aeb043f87f2bbec0a5b8b2->leave($__internal_10d8528bdd0cc587fbae6784037e5bad926d669cf5aeb043f87f2bbec0a5b8b2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
