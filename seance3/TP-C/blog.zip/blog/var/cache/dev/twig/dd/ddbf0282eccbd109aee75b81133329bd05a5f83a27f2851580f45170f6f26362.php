<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_581c53df7a6140282f644ed13796f003fd144279c4ec47e168a4337e8496e827 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_393ece1a94f849e9f4f34e707b18f0336ff71da081375ae39795f0c13f1c95e4 = $this->env->getExtension("native_profiler");
        $__internal_393ece1a94f849e9f4f34e707b18f0336ff71da081375ae39795f0c13f1c95e4->enter($__internal_393ece1a94f849e9f4f34e707b18f0336ff71da081375ae39795f0c13f1c95e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_393ece1a94f849e9f4f34e707b18f0336ff71da081375ae39795f0c13f1c95e4->leave($__internal_393ece1a94f849e9f4f34e707b18f0336ff71da081375ae39795f0c13f1c95e4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
